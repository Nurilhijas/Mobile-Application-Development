package com.example.notificationapp;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.Calendar;
public class MainActivity extends Activity {
    EditText txtInfo;
    Button btnSend;
    public final static String NOTIFICATION_DATA =
            "NOTIFICATION_DATA";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtInfo = (EditText) this.findViewById(R.id.editText);
        btnSend = (Button) this.findViewById(R.id.button);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createNotification(Calendar.getInstance().getTimeInMillis(),
                        txtInfo.getText().toString());
            } }); }
    private void createNotification(long time, String text){
        String notificationContent = "Detail : Press to show detail !";
        String notificationTitle = "Notification";
        Bitmap largeicon =
                BitmapFactory.decodeResource(getResources(),
                        R.drawable.ic_launcher_background);
        int smallicon = R.drawable.ic_launcher_background;
        Intent intent = new Intent(getApplicationContext(),
                NotifDetailActivity.class);
        intent.putExtra(NOTIFICATION_DATA, "Detail : " + text);
        intent.setData(Uri.parse("content://"+time));
        PendingIntent pendingIntent =
                PendingIntent.getActivity(getApplicationContext(), 0, intent, Intent.FLAG_ACTIVITY_NEW_TASK);
        NotificationManager notificationManager
                = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder;
        builder = new NotificationCompat.Builder(getApplicationContext());
        builder.setWhen(time)
                .setContentText(notificationContent)
                .setContentTitle(notificationTitle)
                .setSmallIcon(smallicon)
                .setAutoCancel(true)
                .setTicker(notificationTitle)
                .setLargeIcon(largeicon)
                .setDefaults(Notification.DEFAULT_LIGHTS |
                        Notification.DEFAULT_SOUND|
                        Notification.DEFAULT_VIBRATE)
                .setContentIntent(pendingIntent);
        Notification notification = builder.build();
        notificationManager.notify((int)time, notification);
    }
}